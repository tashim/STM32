/*
 * func.c
 *
 *  Created on: 12 Nov 2021
 *      Author: sevgeny
 */
#include "main.h"
#include <stdio.h>
#include <string.h>

extern uint8_t rx_buff[rx_buff_SIZE];
extern UART_HandleTypeDef huart5;
extern UART_HandleTypeDef huart3;

extern int rx_flag;

void USER_UART_IRQHandler(UART_HandleTypeDef *huart);

//===========================================================================
/*
 * function for printf
 */
int __io_putchar(int ch)
{
	HAL_UART_Transmit(&huart3, (uint8_t *)&ch, 1, 0xFFFF);
	return ch;
}
//===========================================================================

void USER_UART_IRQHandler(UART_HandleTypeDef *huart)
 {
		  if (__HAL_UART_GET_FLAG(&huart5, UART_FLAG_IDLE) !=RESET)
		  {
			  HAL_UART_DMAStop(&huart5);
			  __HAL_UART_CLEAR_IDLEFLAG(&huart5);
			  __HAL_UART_DISABLE_IT(&huart5, UART_IT_IDLE);
			  rx_flag = 1;
			  __HAL_UART_ENABLE_IT(&huart5, UART_IT_IDLE);
			  HAL_UART_Receive_DMA(&huart5, rx_buff, rx_buff_SIZE);
		  }
 }

